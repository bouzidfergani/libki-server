create table foo ( id integer not null primary key, foo varchar(32) );

insert foo values ( 1, 'Hello World\n' );

;


