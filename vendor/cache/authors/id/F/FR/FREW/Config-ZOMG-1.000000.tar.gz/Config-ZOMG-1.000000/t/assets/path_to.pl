{   
    home => 'a-galaxy-far-far-away',
    path_to => '__path_to(tatooine)__',
}
