package TestAppMetaCompat;
use base qw/Catalyst/;

__PACKAGE__->config(name => __PACKAGE__);
__PACKAGE__->setup;

1;

